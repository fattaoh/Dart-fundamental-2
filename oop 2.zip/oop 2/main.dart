import 'animal.dart';

void main(List<String> args) {
  var ucupCat = Animal('Garfield', 'Orange', 5.5);

  ucupCat.eat(){
    print(ucupCat.weight);
  }
}